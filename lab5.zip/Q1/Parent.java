package Q1;

public class Parent {
	public void display() {
		System.out.println("This is parent class");
	}
	public static void maih(String[]args) {
		Parent in = new Parent();
		
		in.display();
	}

}
