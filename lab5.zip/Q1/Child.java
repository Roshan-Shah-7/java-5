package Q1;

public class Child extends Parent  {
	public void displayc() {
		System.out.println("This is child class");
	}
	public static void main(String[]args) {
		Child in = new Child();
		
		in.display();
		in.displayc();
	}
}
