package Q4;

public class Shape {
	public void disShap() {
		System.out.println("This is This is shape");
	}
}
