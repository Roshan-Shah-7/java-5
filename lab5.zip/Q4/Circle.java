package Q4;

public class Circle extends Shape {
	void disCir() {
		System.out.println("This is circular shape");
	}
}
