package Q4;

public class Square extends Rectangle {
	void disSqu() {
		System.out.println("Swuare is a rectangle");
	}
	
	public static void main(String[]args) {
		Square in = new Square();
		in.disShap();
		in.disRec();
	}
}
