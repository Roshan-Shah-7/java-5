package Q4;

public class Rectangle extends Shape {
	public void disRec() {
		System.out.println("This is rectangle shape");
	}
}
