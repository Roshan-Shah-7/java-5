package Q5;

public abstract class Bank {
	public abstract void getbalance();
}
